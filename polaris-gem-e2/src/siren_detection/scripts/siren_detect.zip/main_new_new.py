#!/usr/bin/env python
from imp import acquire_lock
import cv2
import numpy as np
import matplotlib.pyplot as plt
import soundcard as sc                  # https://github.com/bastibe/SoundCard
import threading, queue
import time
import rospy
from sensor_msgs.msg import Joy

import os
# from pythoncom import CoInitializeEx
# from pythoncom import CoUninitialize
from pyAudioAnalysis import audioBasicIO
from pyAudioAnalysis import ShortTermFeatures
#import noisereduce as nr
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.autograd import Variable
import torch.nn.functional as F
sigmoid = nn.Sigmoid()
import scipy
from scipy import fftpack
from scipy import signal, misc
from scipy.signal import find_peaks

from data import Data

from sensing import camera_thread
from sensing import mic_thread 

from perception import detectSiren
from perception import detectLights


# yolo = torch.hub.load('ultralytics/yolov5', 'yolov5s')
# print(model)


def brake():
    joy_pub = rospy.Publisher('/game_control/joy', Joy, queue_size=1)
    joy_cmd = Joy()
    i = 0
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        i +=1
        joy_cmd.axes = (-0.0, 6.103701889514923e-05, -0.01, -0.0, 6.103701889514923e-05, 1.0, -0.0, -0.0)
        joy_cmd.buttons = (0,0,0,0,0,0,0,0,0,0,0)
        joy_pub.publish(joy_cmd)

        rate.sleep()
    return
def unbrake():
    joy_pub = rospy.Publisher('/game_control/joy', Joy, queue_size=1)
    joy_cmd = Joy()
    rate = rospy.Rate(10) # 10hz
    joy_cmd.axes = (-0.0, 6.103701889514923e-05, 1, -0.0, 6.103701889514923e-05, 1.0, -0.0, -0.0)
    joy_cmd.buttons = (0,0,0,0,0,0,0,0,0,0,0)
    joy_pub.publish(joy_cmd)

    rate.sleep()
    return

def listener():

    rospy.init_node('listener', anonymous=True)

    #rospy.Subscriber("", , brake)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()


def real_time(data_class, mic_lock, camera_lock):
    """Thread used for processing Mic and Camera data for Emergency
       Vehichle Detection

    Args:
        data_class (class): Stores our Real-Time Mic and Camera Data
        mic_lock (lock): Microphone Lock
        camera_lock (lock): Camera Lock
    """   

    while(1):
        time.sleep(0.5)
        if(getattr(data_class, "q_mic").qsize() > 0):

            siren_out = detectSiren(data_class.mic_get_sample())
            setattr(data_class, "siren_confidence", float(siren_out))
            state_out = data_class.siren_update()

            # Initiate Breaking
            if(state_out == True):
                brake()
                # do breaking stuff
            else:
                unbrake() 

            
            
            print(siren_out, state_out)
            
            # lights_out = detectLights(getattr(data_class, 'red_counts'), getattr(data_class, 'blue_counts'))
            # setattr(data_class, "light_confidence", float(lights_out))
            # print(siren_out, lights_out)





if __name__ == "__main__":
    rospy.init_node('gnss_pp_node_new', anonymous=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data_class = Data()
    #cap = cv2.VideoCapture(0)  
    # cap = cv2.VideoCapture(2)                 # Gray Scale Feed on GEM
    cap = cv2.VideoCapture(4)                   # Color Feed on GEM
    #brake()
    mic_lock = threading.Lock()
    camera_lock = threading.Lock()

    t1 = threading.Thread(target=mic_thread, args=(data_class, mic_lock))
    t2 = threading.Thread(target=camera_thread, args=(cap, data_class, camera_lock))
    t3 = threading.Thread(target=real_time, args=(data_class, mic_lock, camera_lock))

    # Start Threads 
    t1.start()
    t2.start()
    t3.start()

    t2.join()
    
